class FetalCLIP:
    def predict(self, image_path):
        return "FetalCLIP: Условный диагноз по изображению"
