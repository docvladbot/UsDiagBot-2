class FetalNet:
    def predict(self, image_path):
        return "FetalNet: Условный диагноз по изображению"
